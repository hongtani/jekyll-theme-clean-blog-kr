---
layout: post
permalink: /tokyo-olympic/
title: Japan will host the Olympics
date: 2021-05-26 21:30:00 +09:00
feature: '/img/posts/tokyo-olympic2021/tokyo-2.jpg'
categories:
  - to
tags:
  - tokyo
  - Olympics
  - Japan
description: Why don't you believe it when it's scientifically safe?
---

# IOC member says Japan will host the Olympics even if Prime Minister asks for cancellation #


![tokyo-olympic](/img/posts/tokyo-olympic2021/tokyo-2.jpg)

## The opposition to the convention is to ignore scientific evidence. ##

Amid mounting public opinion to cancel the Tokyo Olympics and Paralympics in Japan, the longest-serving member of the International Olympic Committee (IOC) said, "Even if Prime Minister Yoshihide Suga demands a halt, the competition will be held," Shukanbunshun said in an exclusive interview.

It is true that the IOC, not the Japanese government, has the authority to cancel or postpone the Olympics, but the remarks are expected to have a huge impact as they mean it is okay to ignore the host country's intention.

IOC member Dick Pound, 79, made the announcement in an interview on the 23rd, confirming the Olympic Games. Pound, a former Canadian swimmer, is the longest-serving IOC member who served as vice-chairman under Juan Antonio Samaranch.

---

#### Koreans' Thoughts on the Enforcement of the Tokyo Olympics ####
![tokyo-olympic](/img/posts/tokyo-olympic2021/001.jpg)

>Stop talking nonsense and say no cancellation for money.LOL, 
you keep beating around the bush.lol

>Where's the Olympic spirit? Break up the IOC and end the Olympics.

>Then doesn't the safety of the players matter?

>If you're so confident, bet something. Players should probably risk their lives for the aftermath of Corona, and you're not God.How can you guarantee safety? If you're so confident, bet something. For your information, I really hope to do Tokyo Olympics, hoping that the result will be a serious problem for Japan.

>It's scientifically safe, but why don't the Japanese people believe it?Lol, like the chairman said, why would he do without an audience?You said it was scientifically safe.

---

#### Koreans' Thoughts on the Enforcement of the Tokyo Olympics2 ####
![tokyo-olympic](/img/posts/tokyo-olympic2021/002.jpg)

>Japan, China and the IOC are crazy. You're trying to kill players 
and others all over the world because they're so crazy about money.

>Selfish people, blinded by money, belittled life.

>That's a big deal. Ioc councilor ignores Suga. Maybe they think the Japanese prime minister's opinion is personal. They doesn't even treat him like a colon monkey.

>Oh, cool, their determination never to give up money. LOL

>He's roughly saying cause it's not his country.
I don't think he's going to Japan for the Olympics.

---


## In an interview, he blamed the Japanese people ##

He says, "It is regrettable that most of the Japanese people have a negative opinion on hosting the event, but there is scientific evidence that there is no additional risk even if the competition is held." "Scientific is fine, I guess I'm just saying 'no'. "If we hold it, we will definitely celebrate its success," he said, arguing that the public's opposition to the hosting is unscientific.


![tokyo-olympic2](/img/posts/tokyo-olympic2021/tokyo-1.jpg)

However, it was desirable to make sure that there were no spectators when hosting. "If you think about safety, you shouldn't let the crowd in," he said.

And he went on to say, "To be honest, 99.5 percent of the world will be enjoyed on TV or Internet platforms, so it's not important for the audience to enter the venue."

When asked about the criteria for deciding to cancel the event, he replied, "Is there an unacceptable risk?" "We can control everything scientifically," he said. "We are not concerned about health and safety. "Even if the prime minister demands a halt, it is only a personal opinion to the extent of the situation. "The competition will be held."

In the wake of a series of recent insensitive remarks by key IOC executives who did not take into account Japanese public sentiment, Dick Pound's remarks are likely to provoke opposition. IOC Vice Chairman John Coats' remarks that "even if an emergency is being issued" and Thomas Bach's remarks that "we must make sacrifices" called for a backlash, saying, "Do we have to sacrifice the health and life of the Japanese people?"
