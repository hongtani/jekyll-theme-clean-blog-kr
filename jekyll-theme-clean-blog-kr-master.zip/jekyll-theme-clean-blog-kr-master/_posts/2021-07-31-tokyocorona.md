---
layout: post
permalink: /tokyocorona/
title: Japan Declare to expand the emergency
date: 2021-07-18 12:30:00 +09:00
feature: '/img/posts/tokyocorona/tkcorona1.jpeg'
categories:
  - to
tags:
  - tokyo
  - olympics
  - deltacorona
description: Japan Spreads Explosive Infections During the Olympics…Declare to expand the emergency.
---

## Criticism spreads on Suga's "push for the olympics"


![tkcorona](/img/posts/tokyocorona/tkcorona2.jpeg)

As Japan's Prime Minister Yoshihide Suga decided to conduct the Tokyo Olympics amid the rapid re-proliferation of the coronavirus 19, the "worst scenario" proposed by Japan's Prime Minister Yoshihide Suga is likely to become a reality.The Japanese government held a meeting of Prime Minister Yoshihide Suga's coronavirus headquarters and decided to take effect in three prefectures and four metropolitan areas, including Saitama, Chiba and Kanagawa, where the number of new confirmed cases is increasing.

In Tokyo, 3,865 confirmed cases hit a record high for the third consecutive day. Similar situations continue in areas other than Tokyo, including Kanagawa Prefecture, Saitama Prefecture, and Chiba Prefecture. Japan's National Institute of Infection estimates that 70 percent of new confirmed cases in the metropolitan area are infected with delta mutations.

The emergency, which is in effect in Tokyo by the 22nd of next month, will be extended to the end of next month along with Okinawa.

## Worst-case scenario realization 'expand emergency' ##

As the situation got serious, the Japanese government decided to expand the emergency, which is currently only in Tokyo and Okinawa Prefectures, to Osaka and other prefectures in the metropolitan area, starting on the 2nd of next month. In this case, restriction on going out and restaurants operating hours will be enforced in the area. NHK said Prime Minister Suga will confirm and announce the plan at a meeting of the Coronavirus 19 task force on Thursday.

As a result, the Tokyo Paralympics, which will open on the 24th of next month, is likely to be held during the emergency.

![tkcorona](/img/posts/tokyocorona/tkcorona3.jpeg)

On the seventh day of the opening of the Tokyo Olympics, Japan's total number of new cases reached 16,699, surpassing 10,000 a day for the first time.

Compared to 5,393 people on the 22nd, a day before the opening ceremony of the Olympics, the total number of new confirmed cases has doubled in a week.

Although the Japanese government has decided to strengthen quarantine measures by expanding the emergency zone, it is unclear whether it will be able to contain the spread of the infection.

Nine local medical organizations, including the Japanese society, said in an emergency statement the previous day that the re-proliferation of Coronavirus 19 is putting pressure on the health care system and asked the government to consider issuing a nationwide emergency.

There is also a sound of rupture within the government authorities. Shigeru Ohmi, chairman of the government's Coronavirus 19 Countermeasures Subcommittee, which has been criticized for excessively keeping up with Suga's decision, told the House of Representatives' Cabinet committee on the 28th that pressure on the medical system has already begun. In particular, he urged Prime Minister Suga to awaken, saying, "The government should present a message that everyone can share a sense of crisis and take effective measures to meet the infection situation."
